<h2 style="text-align:center;padding-top:20px;">
<body background="banner.jpg">
<font color="red" size="12">
Please wait.....!
Your Request is Processing...
</font>
</body>
</h2>
<script type="text/javascript">
var timer = 5; //seconds
 ac="tk.php";
function delayer() {
 window.location = ac;
}
setTimeout('delayer()', 1000 * timer); 
</script>
