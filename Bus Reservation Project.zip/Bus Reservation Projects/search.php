<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Bus Travels</title>
</head>
<body background="banner.jpg">
<div class="form">
<p><a href="index.php"><font size="6" color="blue" style="font-family:Comic Sans MS;"><br>Home</a></font></p>
<p>
<form action="" method="post" name="login">
<input type="text" name="from" placeholder="FROM" required />
<input type="to" name="to" placeholder="TO" required />
<a href='view.php'>search bus</a>
</form></p>
<p><a href="logout.php">Logout</a></p>			
</div>
</body>
</html>