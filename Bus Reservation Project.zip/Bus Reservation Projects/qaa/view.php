<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>bus travels</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a> 
| <a href="logout.php">Logout</a></p>
<h2>bus travels</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>S.No</strong></th>
<th><strong>travels Name</strong></th>
<th><strong>route</strong></th>
<th><strong>timing</strong></th>
<th><strong>INR</strong></th>
</tr>
<tr>
<td>1</td>
<td>Sundara Travels</td>
<td>chennai to madurai</td>
<td>5.00am-10.00am</td>
<td>500</td>
</tr>
<tr>
<td>2</td>
<td>Suresh Travels</td>
<td>coimbatore to madurai</td>
<td>7.00am-11.00am</td>
<td>650</td>
</tr>
<tr>
<td>3</td>
<td>Krish Travels</td>
<td>chennai to coimbatore</td>
<td>2.00am-8.00am</td>
<td>700</td>
</tr>
<tr>
<td>4</td>
<td>vijay Travels</td>
<td>delhi to mumbai</td>
<td>6.00am-2.00am</td>
<td>1600</td>
</tr>
<tr>
<td>5</td>
<td>veesanth Travels</td>
<td>thirunelveli to bangalore</td>
<td>9.00am-3.00am</td>
<td>1500</td>
</tr>
<tr>
<td>6</td>
<td>penita Travels</td>
<td>naagarkovil to chennai</td>
<td>3.00pm-10.00pm</td>
<td>1600</td>
</tr>
<tr>
<td>7</td>
<td>karthi Travels</td>
<td>ooty to chennai</td>
<td>3.00pm-6.00pm</td>
<td>900</td>
</tr>
<tr>
<td>8</td>
<td>jamme Travels</td>
<td>kodaikanal to chennai</td>
<td>3.40am-7.00am</td>
<td>650</td>
</tr>
<tr>
<td>9</td>
<td> Travels</td>
<td>coimbatore to trivandrum</td>
<td>6.30pm-9.00pm</td>
<td>450</td>
</tr>
<tr>
<td>10</td>
<td>SRM Travels</td>
<td>salem to hyderabad</td>
<td>3.00am-8.00am</td>
<td>800</td>
</tr>
<tr>
<td>10</td>
<td>VSM Travels</td>
<td>madurai to hyderabad</td>
<td>8.00pm-5.00am</td>
<td>2500</td>
</tr>
<tr>
<td>11</td>
<td>velammal Travels</td>
<td>ooty to madurai</td>
<td>5.00am-9.00am</td>
<td>900</td>
</tr>
<tr>
<td>12</td>
<td>shanmuga Travels</td>
<td>ramnad to chennai </td>
<td>4.00am-8.00am</td>
<td>1200</td>
</tr>
<tr>
<td>13</td>
<td>Harsini Travels</td>
<td>chennai to madurai</td>
<td>12.00pm-6.00pm</td>
<td>700</td>
</tr>
<tr>
<td>14</td>
<td>Ruby Travels</td>
<td>Sivagangai to madurai</td>
<td>5.00pm-9.00pm</td>
<td>600</td>
</tr>
<tr>
<td>15</td>
<td>Rakshi Travels</td>
<td>Dindugal to madurai</td>
<td>12.00am-2.00pm</td>
<td>560</td>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="Select * from new_record ORDER BY id desc;";
$result = mysqli_query($con,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["name"]; ?></td>
<td align="center"><?php echo $row["age"]; ?></td>
<td align="center">
<a href="edit.php?id=<?php echo $row["id"]; ?>">Edit</a>
</td>
<td align="center">
<a href="delete.php?id=<?php echo $row["id"]; ?>">Delete</a>
</td>
</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>