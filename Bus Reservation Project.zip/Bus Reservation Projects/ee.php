<h2 style="text-align:center;padding-top:20px;">
<img src="aa.jpg"style="width:1366px;height:560px;">
<script type="text/javascript">
var timer = 3; //seconds
 ac="login.php";
function delayer() {
 window.location = ac;
}
setTimeout('delayer()', 1000 * timer); 
</script>
