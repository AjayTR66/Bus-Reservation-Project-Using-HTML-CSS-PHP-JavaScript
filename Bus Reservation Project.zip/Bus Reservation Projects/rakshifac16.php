<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Facilities</title>
</head>
<body background="banner.jpg">
<div class="form">
<p align="center"><font size="6" color="aqua" style="font-family:Comic Sans MS;">Amenities</font</p>
<p style="display:inline;padding-right: 5.18cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:80pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Blankets</font</p>&nbsp;&nbsp;
<p style="display:inline;padding-right:5cm";><input type="checkbox" name="name" size="30" checked="checked"style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Fire Extinguisher</font></p><br><br>
<p style="display:inline;padding-right: 6.07cm";><input type="checkbox" name="name" size="30"style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Pillows</font></p>
<p style="display:inline;padding-right: 4cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:80pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Personal TV</font></p><br><br>
<p style="display:inline;padding-right: 3cm";><input type="checkbox" name="name" size="30" checked="checked"style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Charging point</p>&nbsp;&nbsp;&nbsp;&nbsp;
<p style="display:inline;padding-right: 10cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Movie</p>
<p style="display:inline;padding-right: 3cm";><a href="sur.php"><font size="5" color="aqua" style="font-family:Comic Sans MS;">Proceed</a></p>
<p style="display:inline;padding-right: 4cm";><a href="view.php"><font size="5" color="red" style="font-family:Comic Sans MS;">Cancel</a>
<br><br>
<p style="display:inline;padding-right: 2.95cm";><input type="checkbox" name="name" size="30" checked="checked"style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Emergency Exit</p>&nbsp;&nbsp;
<p style="display:inline;padding-right: 4cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Track my bus</p><br><br>
<p style="display:inline;padding-right: 4cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Reading Light</p>
<p style="display:inline;padding-right: 4cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Wifi</p><br><br>
<p style="display:inline;padding-right: 4.7cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Music/MP3</p>
<p style="display:inline;padding-right: 4cm";><input type="checkbox" name="name" size="30" checked="checked"style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">Water Bottle</p><br><br>
</div>
</body>
</html>