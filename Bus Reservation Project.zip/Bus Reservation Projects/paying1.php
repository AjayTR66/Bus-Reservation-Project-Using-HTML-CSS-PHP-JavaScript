<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Facilities</title>
</head>
<body background="banner.jpg">
<div class="form">
<p><font size="6" color="aqua" style="font-family:Comic Sans MS;"><br>Select Bank</p></font>
<p style="display:inline;padding-right: 5.18cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:80pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">SBI</font</p>&nbsp;&nbsp;
<p style="display:inline;padding-right: 5.18cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:80pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">IOB</font</p>&nbsp;&nbsp;
<p style="display:inline;padding-right: 5.18cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:80pt;">
<font size="5" color="orange" style="font-family:Comic Sans MS;">BOI</font</p>&nbsp;&nbsp;
<p align="center"><input type="number" name="name" size="30" style="font-family:Comic Sans MS;font-size:18pt;height: 30px;"placeholder="Enter 14 digit card number.." required /></p>
<p align="center"><input type="number" name="name" size="30" style="font-family:Comic Sans MS;font-size:18pt;height: 30px;"placeholder="Enter 4 digit pin number.." required /></p>
<p><a href="jammetravels.php"><br><font size="6" color="yellow" style="font-family:Comic Sans MS;">Proceed to pay</a></p></font>
</div>
</body>
</html>

