<?php
	include "langsettings.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta name="author" content="Kai Oswald Seidler, Kay Vogelgesang, Carsten Wiedmann">
		<link href="xampp.css" rel="stylesheet" type="text/css">
		<title></title>
	</head>

	<body>
		&nbsp;<p>
		<h1><?php echo $TEXT['mail-head']; ?></h1>
		<table width="600" cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td align="left" width="600">
					<?php echo $TEXT['mail-help1']; ?>
					<?php echo $TEXT['mail-help2']; ?>
					<?php echo $TEXT['mail-url']; ?>
					&nbsp;<p>
					<img src="img/mercury1.gif" width="467" height="436" border="0" alt="">
					<br>&nbsp;<br>
					<img src="img/mercury2.gif" width="565" height="488" border="0" alt="">
				</td>
			</tr>
		</table>
	</body>
</html>
