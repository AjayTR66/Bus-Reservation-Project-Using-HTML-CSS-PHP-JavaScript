<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<div align ="center">
<h2 style="text-align:center;padding-top:20px;">
<marquee width="700" style="font-family:Book Antiqua; color: #FFFFFF" scrollamount="20">
 <font size="7" color="red" style="font-family:Comic Sans MS;"> Online Bus Reservtion System
</font></marquee>
</h2>
<title>Login</title>
</head>
<body background="banner.jpg">
<?php
require('db.php');
session_start();
// If form submitted, insert values into the database.
if (isset($_POST['username'])){
        // removes backslashes
	$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($con,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `users` WHERE username='$username'
and password='".md5($password)."'";
	$result = mysqli_query($con,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
        if($rows==1){
	    $_SESSION['username'] = $username;
            // Redirect user to index.php
	    header("Location: index.php");
         }else{
?><div class="form">
<p><font size="6" color="aqua" style="font-family:Comic Sans MS;"><br>Username/password is incorrect.<p></font>
<br/><font size="6" color="pink" style="font-family:Comic Sans MS;">Click here to </font><a href='login.php'>
<font size="6" color="yellow" style="font-family:Comic Sans MS;">Login</a>
</font></div><?php	}
    }
	else{
?>
<div class="form">
<h1><font size="6" color="pink" style="font-family:Comic Sans MS;"><br>Log In<br/></h1>
<form action="" method="post" name="login">
<input type="text" name="username" size="20" style="font-family:Comic Sans MS;font-size:15pt;height: 20px;"placeholder="Username" required />
<input type="password" name="password" size="20" style="font-family:Comic Sans MS;font-size:15pt;height: 20px;"placeholder="Password" required />
<input name="submit" type="submit"size="20" style="font-family:Comic Sans MS;font-size:10pt;height: 30px;" value="Login" />
</form>
<p align="center"><font size="6" color="yellow" style="font-family:Comic Sans MS;">Not registered yet?</font></p> <a href='registration.php'><font size="6" color="white" style="font-family:Comic Sans MS;">Register Here</font></a></p>
</div>
<?php } ?>
</body>
</html>