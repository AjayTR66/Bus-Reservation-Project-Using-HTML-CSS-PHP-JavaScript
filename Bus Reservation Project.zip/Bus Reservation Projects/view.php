<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>bus travels</title>
</head>
<body background="banner.jpg">
<div class="form">
<p><a href="index.php"><font size="3" color="yellow" style="font-family:Comic Sans MS;">HOME</font></a> 
<div class="container">
<div class="topright"><a href="logout.php"><font size="3" color="yellow" style="font-family:Comic Sans MS;">LOGOUT</font></a></div>
</div>
</p>
<h2><font size="6" color="red" style="font-family:Comic Sans MS;"><center>BUS TRAVELS</center></font></h2>
<table width="100%" border="" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong><font size="4"color="white" style="font-family:Comic Sans MS;">S.No</font></strong></th>
<th><strong><font size="4"color="white" style="font-family:Comic Sans MS;">TRAVELS NAME</font></strong></th>
<th><strong><font size="4"color="white" style="font-family:Comic Sans MS;">ROUTE</font></strong></th>
<th><strong><font size="4"color="white" style="font-family:Comic Sans MS;">TIMING</font></strong></th>

<th><strong><font size="4"color="white" style="font-family:Comic Sans MS;">INR</font></strong></th>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">1</font></td>
<td><a href="sundarafac1.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Sundara travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Chennai to Madurai</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">5.00am-10.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">500</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">2</font></td>
<td><a href="sureshfac2.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Suresh travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Coimbatore to Madurai</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">7.00am-11.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">650</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">3</font></td>
<td><a href="krishfac3.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Krish travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Chennai to Coimbatore</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">2.00am-8.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">700</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">4</font></td>
<td><a href="vijayfac4.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Vijay travels</font></font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Delhi to Mumbai</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">6.00am-2.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">1600</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">5</font></td>
<td><a href="luckyfac5.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Lucky travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Thirunelveli to Bangalore</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">9.00am-3.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">1500</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">6</font></td>
<td><a href="dreamfac6.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Dream travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Naagarkovil to Chennai</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">3.00pm-10.00pm</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">1600</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">7</font></td>
<td><a href="aaafac7.php"><font size="4"color="white" style="font-family:Comic Sans MS;">AAA travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">ooty to chennai</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">3.00pm-6.00pm</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">900</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">8</font></td>
<td><a href="jammefac8.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Jamme travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Kodaikanal to Chennai</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">3.40am-7.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">650</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">9</font></td>
<td><a href="parveenfac9.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Parveen travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Coimbatore to Trivandrum</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">6.30pm-9.00pm</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">450</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">10</font></td>
<td><a href="srmfac10.php"><font size="4"color="white" style="font-family:Comic Sans MS;">SRM travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Salem to Hyderabad</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">3.00am-8.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">800</font></td>
</tr>
<tr>
<td><font size="3"color="white" style="font-family:Comic Sans MS;">11</font></td>
<td><a href="asfac11.php"><font size="4"color="white" style="font-family:Comic Sans MS;">AS travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Madurai to Hyderabad</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">8.00pm-5.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">2500</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">12</font></td>
<td><a href="adfac12.php"><font size="4"color="white" style="font-family:Comic Sans MS;">AD travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Ooty to Madurai</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">5.00am-9.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">900</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">13</font></td>
<td><a href="shanmugafac13.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Shanmuga travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Ramnad to Chennai </font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">4.00am-8.00am</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">1200</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">14</td>
<td><a href="harsinifac14.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Harsini travels</a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Chennai to Madurai</td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">12.00pm-6.00pm</td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">700</td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">15</font></td>
<td><a href="rubyfac15.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Ruby travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Sivagangai to Madurai</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">5.00pm-9.00pm</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">600</font></td>
</tr>
<tr>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">16</font></td>
<td><a href="rakshifac16.php"><font size="4"color="white" style="font-family:Comic Sans MS;">Rakshi travels</font></a></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">Dindugal to Madurai</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">12.00am-2.00pm</font></td>
<td><font size="4"color="white" style="font-family:Comic Sans MS;">560</font></td>
</tr>
</thead>
</table>
</div>
</body>
</html>