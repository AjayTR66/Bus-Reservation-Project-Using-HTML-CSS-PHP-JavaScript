<h2 style="text-align:center;padding-top:20px;">
<body background="banner.jpg">
<font color="red" size="15">
Ticket Booked Successfully
</font>
</body>
</h2>
<script type="text/javascript">
var timer = 2; //seconds
 ac="tkk.php";
function delayer() {
 window.location = ac;
}
setTimeout('delayer()', 1000 * timer); 
</script>

