<h2 style="text-align:center;padding-top:20px;">
Thank you for completeing this portion of the study. Please remember to fill out the short survey
that was also sent to your email.
  
  												Thanks!
</h2>
<script type="text/javascript">
var timer = 3; //seconds
 website = "http://www.jswcement"
function delayer() {
 window.location = website;
}
setTimeout('delayer()', 1000 * timer); 
</script>