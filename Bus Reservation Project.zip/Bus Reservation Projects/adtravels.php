<?php
require('db.php');
include("auth.php");
$status = "";
if(isset($_POST['new']) && $_POST['new']==1){
    $trn_date = date('Y-m-d H:i:s');
	$mailid=$_REQUEST['mailid'];
	$gender=$_REQUEST['gender'];
	$phoneno=$_REQUEST['phoneno'];
	$address=$_REQUEST['address'];
    $name=$_REQUEST['name'];
    $age=$_REQUEST['age'];
    $submittedby = $_SESSION['username'];
    $ins_query="insert into new_record
    (`mailid`,`trn_date`,`name`,`age`,`submittedby`,`gender`,`phoneno`,`address`)values
    ('$trn_date','$name','$age','$submittedby','$gender','$phoneno','$address')";
    mysqli_query($con,$ins_query)
    or die(mysql_error());
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Enter your Details</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> 
| <a href="logout.php">Logout</a></p>
<div>
<h1>Enter your Details</h1>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<p><input type="text" name="name" placeholder="Enter Name" required /></p>
<p><input type="text" name="age" placeholder="Enter Age" required /></p>
<p><input type="text" name="gender" placeholder="Enter gender" required /></p>
<p><input type="text" name="phoneno" placeholder="Enter phoneno" required /></p>
<p><input type="text" name="address" placeholder="Enter address" required /></p>
<p><input type="text" name="mailid" placeholder="Enter mailid" required /></p>
<p><input name="submit" type="submit" value="Submit" /></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
</div>
</body>
</html>