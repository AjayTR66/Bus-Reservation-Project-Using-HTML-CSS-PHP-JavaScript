<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Bank</title>
</head>
<body>
<div class="form">
<p align="center"><font size="6" color="aqua" style="font-family:Comic Sans MS;"><br>".............Secured Bank Site........."</p></font>
<p><font size="6" color="aqua" style="font-family:Comic Sans MS;"><br>"Enter the Amount"</p></font>
<p style="display:inline;padding-right: 5.18cm";><input type="number" name="name" size="30"</p>&nbsp;&nbsp;
