<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Online bus ticket booking System</title>
</head>
<body background="banner.jpg">
<div class="form">
<p><center><font size="7" color="orange" style="font-family:Comic Sans MS;"><br>Welcome <?php echo $_SESSION['username']; ?>!<br/></font></center></p>
<p><center><a href="dashboard.php"><font size="6" color="aqua" style="font-family:Comic Sans MS;"><br>Book Ticket<br/></center></font></a>
</p><center><a href="logout.php"><font size="6" color="fechisa" style="font-family:times new roman;">Logout</center></font></a>
</div>
</body>
</html>