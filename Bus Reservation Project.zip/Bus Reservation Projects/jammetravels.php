<?php
require('db.php');
include("auth.php");
$status = "";
if(isset($_POST['new']) && $_POST['new']==1){
	$mailid=$_REQUEST['mailid'];
	$gender=$_REQUEST['gender'];
	$phoneno=$_REQUEST['phoneno'];
	$address=$_REQUEST['address'];
    $name=$_REQUEST['name'];
    $age=$_REQUEST['age'];
    $submit = $_SESSION['username'];
    $ins_query="insert into new_record
    (`mailid`,`name`,`age`,`submit`,`gender`,`phoneno`,`address`)values
    ('$name','$age','$submit','$gender','$phoneno','$address')";
      $result = mysqli_query($con,$ins_query);
	if($result)
	{
	?>
	<div class="form">
	<p>hi</p></div>
	<?php
	}
	else
	{
	header("Location: thankyou.php");
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Enter your Details</title>
</head>
<body background="banner.jpg">
<div class="form">
<p style="display:inline;padding-right:32cm";> <a href="index.php"><font size="4" color="yellow" style="font-family:Comic Sans MS;">Home</a></p>
<p style="display:inline;padding-right:0cm";> <a href="logout.php"><font size="4" color="yellow" style="font-family:Comic Sans MS;">Logout</a></p>
<div>
<h1><center><font size="6" color="aqua" style="font-family:Comic Sans MS;">Enter your Details</h1>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<p align="center"><input type="text" name="name" size="30" style="font-family:Comic Sans MS;font-size:18pt;height: 30px;"placeholder="Enter Name" required /></p>
<p align="center"><input type="text" name="age" size="30" style="font-family:Comic Sans MS;font-size:18pt;height: 30px;"placeholder="Enter Age" required /></p>
<p style="display:inline;padding-left: 11cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:80pt;">
<font size="5" color="white" style="font-family:Comic Sans MS;">Male</font></p>
<p style="display:inline;padding-right: 7cm";><input type="checkbox" name="name" size="30" style="width:60px;height:20px;font-family:Comic Sans MS;font-size:18pt;">
<font size="5" color="white" style="font-family:Comic Sans MS;">Female</p>&nbsp;&nbsp;&nbsp;&nbsp;
<p align="center"><input type="text" name="phoneno" size="30" style="font-family:Comic Sans MS;font-size:18pt;height: 30px;"placeholder="Enter phoneno" required /></p>
<p align="center"><input type="text" name="address" size="30" style="font-family:Comic Sans MS;font-size:18pt;height: 30px;"placeholder="Enter address" required /></p>
<p align="center"><input type="text" name="mailid" size="30" style="font-family:Comic Sans MS;font-size:18pt;height: 30px;"placeholder="Enter mailid" required /></p>
<p align="center"><input href="thankyou.php" name="submit" type="submit" size="30" style="font-family:Comic Sans MS;font-size:18pt;height: 30px;" value="Submit" href="thankyou.php"></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
</div>
 </body>
</html>