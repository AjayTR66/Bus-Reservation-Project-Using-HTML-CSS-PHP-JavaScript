<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard - Secured Page</title>
</head>
<body background="banner.jpg">
<div class="form">
<p><br><a href="index.php"><center><font size="6" color="yellow" style="font-family:Comic Sans MS;">Home</a><br></center></font><p>
<p><a href="view.php"><center><font size="6" color="aqua" style="font-family:Comic Sans MS;">View Available Buses</a><br></center></font></p>
<p><a href="logout.php"><center><font size="6" color="lime" style="font-family:Comic Sans MS;">Logout</a><br></center></font></p>
</div>
</body>
</html>